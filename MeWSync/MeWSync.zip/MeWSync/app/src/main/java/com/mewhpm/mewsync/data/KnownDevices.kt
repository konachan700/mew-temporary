package com.mewhpm.mewsync.data

data class KnownDevices(
    val knownDevices: ArrayList<BleDevice> = ArrayList()
)