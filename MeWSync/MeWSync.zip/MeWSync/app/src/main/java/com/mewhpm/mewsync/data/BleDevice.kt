package com.mewhpm.mewsync.data

data class BleDevice(
    val mac: String,
    val name: String
)