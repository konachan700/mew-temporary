package com.mewhpm.mewsync.services

import android.content.Context
import com.google.gson.GsonBuilder
import java.io.File

abstract class JSONable<T>(context: Context) {
    private val gson = GsonBuilder().setPrettyPrinting().create()
    private val file = File("${context.applicationContext.filesDir.absolutePath}${File.separator}${getFileName()}")
    init {
        if (!context.applicationContext.filesDir.exists()) context.applicationContext.filesDir.mkdirs()
        if (!file.exists()) file.createNewFile()
    }

    abstract fun getFileName(): String
    abstract fun getNewObject(): T

    fun load(clazz: Class<T>): T = gson.fromJson(file.readText(), clazz) ?: getNewObject()

    fun save(obj: T, clazz: Class<T>) = file.writeText(gson.toJson(obj, clazz))
}