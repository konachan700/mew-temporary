package com.mewhpm.mewsync.services

import android.content.Context
import com.mewhpm.mewsync.data.BleDevice
import com.mewhpm.mewsync.data.PasswordFolder

class PasswordsService(context: Context, device: BleDevice): JSONable<PasswordFolder>(context) {
    private val _device = device
    private val root: PasswordFolder = load(PasswordFolder::class.java)

    override fun getFileName(): String = "${_device.mac}.json"
    override fun getNewObject(): PasswordFolder = PasswordFolder(
        id = 0,
        name = "root",
        device = _device,
        parent = null
    )

    fun getRoot() = root

    fun isRoot(folder: PasswordFolder) = (folder == root)

    fun saveTree() {
        save(root, PasswordFolder::class.java)
    }
}