package com.mewhpm.mewsync.services

import com.mewhpm.mewsync.data.BleDevice

class BleDeviceSearchDummyImpl: BleDeviceSearch {

    override fun bleDiscover(): List<BleDevice> {
        var list: ArrayList<BleDevice> = ArrayList()
        for (i in 1..5) {
            var dev = BleDevice(mac = "00:00:00:00:00:0$i", name = "MeW HPM $i")
            list.add(dev)
        }
        return list
    }
}