package com.mewhpm.mewsync.services

import android.content.Context
import com.mewhpm.mewsync.data.BleDevice
import com.mewhpm.mewsync.data.KnownDevices

class DeviceService(context: Context): JSONable<KnownDevices>(context) {
    override fun getNewObject(): KnownDevices = KnownDevices()
    override fun getFileName(): String = "devices.json"

    val knownDevices: KnownDevices = load(KnownDevices::class.java)

    fun addDevice(dev: BleDevice) {
        if (knownDevices.knownDevices.contains(dev)) return
        knownDevices.knownDevices.add(dev)
        save(knownDevices, KnownDevices::class.java)
    }

    fun dropDevice(dev: BleDevice) {
        knownDevices.knownDevices.remove(dev)
        save(knownDevices, KnownDevices::class.java)
    }
}