package com.mewhpm.mewsync.data

data class PasswordRecord (
    val url: String,
    val name: String,
    val login: String
)