package com.mewhpm.mewsync.services

import com.mewhpm.mewsync.data.BleDevice

interface BleDeviceSearch {
    fun bleDiscover(): List<BleDevice>
}